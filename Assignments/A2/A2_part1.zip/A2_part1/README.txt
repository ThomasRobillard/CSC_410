ABOUT
Code files for A2 CSC410

DATE: Sep 25 2024

Included files:
A2_p.c // Source code for task 1, creating 4 child processes representing different people from Star Wars
Robillard_A2.pdf // writeup for task 2 and 3, with included screenshot

To compile:
gcc A2_p.c -o A2_p